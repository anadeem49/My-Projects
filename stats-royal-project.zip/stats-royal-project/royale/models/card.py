class Card:
    def __init__(self, id: int, cost: int, icon: str, name: str, type: str, arena: int, rarity: str):
        self.id = id;
        self.cost = cost;
        self.icon = icon;
        self.name = name;
        self.type = type;
        self.arena = arena;
        self.rarity = rarity;