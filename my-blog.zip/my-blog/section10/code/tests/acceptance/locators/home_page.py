from selenium.webdriver.common.by import By


class HomePageLocators:
    NAVIGATION_LINK = By.ID, 'blog-link'
