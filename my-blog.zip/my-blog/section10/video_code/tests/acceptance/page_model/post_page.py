class PostPageLocators:
    pass
