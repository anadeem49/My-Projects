class HomePageLocators:
    pass
