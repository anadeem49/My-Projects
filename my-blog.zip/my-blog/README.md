[![Build Status](https://travis-ci.org/schoolofcode-me/testing-python-apps.svg?branch=master)](https://travis-ci.org/schoolofcode-me/testing-python-apps)

# Testing Python Apps

This repository contains the code covered by each section of my latest course, 'Testing Python Apps'.

It builds on another course, 'REST APIs with Flask and Python', to discuss testing at each level in order to build resilient applications.

Course coming soon!