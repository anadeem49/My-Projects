import time
from agents import Player

# ---------------------------------------------------------------------------
# Ehsan Khosroshahi, updated Nov 2023.
# ---------------------------------------------------------------------------


# --------------------------------------------------------------------------------
# This file is for the student wishes to implement the EXTRA CREDIT.
# --------------------------------------------------------------------------------

#---------------------------------------------------------------------------
# The agent for EXTRA CREDIT.
# Student code needed here. Change the userid to your actual user id (e.g., ebc123)
# This agent, instead of receiving the depth at which to perform a search, receives
# a certain amount of time (in milliseconds) that it can use to search. Make sure
# that your bot returns a solution within this time (you can assume that you will
# have at least 100 milliseconds).
#---------------------------------------------------------------------------
class an948(Player):
    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)
    
    def an948_h(self, board):
    #---------------------------------------------------------------------------
    # include Heuristic evaluation of board, presuming it is player's move.
    # Student code needed here. Change userid to your drexel user id.
    # This will be used for tournament
    #---------------------------------------------------------------------------
        super().an948_h(board);

    
start = time.perf_counter()

an948 = an948(1, "w", 5, 1000);
an948_heuristic = an948.an948_h([1, 2, 3, 5, 8, 11]);

end = time.perf_counter()
execution = end - start
print(f"The execution time is: {execution}")