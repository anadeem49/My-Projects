from abc import abstractmethod
import random
import copy
import treelib

from pentago import PentagoBoard
# ---------------------------------------------------------------------------
# JL Popyack, ported to Python, May 2019, updated Nov 2021. v2 Nov 29, 2021
# Ehsan Khosroshahi, updated Nov 2023.
# ---------------------------------------------------------------------------

#-----------------------------------------------------------------------
# Names for common abbreviations
#-----------------------------------------------------------------------
descr = {
  "b": "Black",
  "w": "White",
}

#--------------------------------------------------------------------------------
# Contains elements for abstract class players defining an agent that can play the 
# game. Each agents is an extention of this class.
# A human agent has been implemented for you as an example that gets the player's  
# move typed in at the console by the player, where either it is accepted as a  
# valid move, or the player is asked again to enter a valid move.
#--------------------------------------------------------------------------------
class Player:

    def __init__ (self,player_number,token, depth_limit, time_limit):
        self.INFINITY = 10000
        self.player_number = player_number
        self.depth_limit = depth_limit
        self.time_limit = time_limit
        
        if token.lower() in ["b","w"]:
            self.token = token.lower()

    def __str__ (self):
        return self.player_number + " is a " + self.__class__.__name__.lower() +  " agent and plays " + descr[self.token].lower() + " tokens."
    
    def player_type(self):
        return self.__class__.__name__
    
    def win(self,board):
    # Check for winner beginning with each element.
    # It is possible that both players have multiple "wins"	
        numWins = 0
        for i in range(board.BOARD_SIZE):
            for j in range(board.BOARD_SIZE):
                if board.board[i][j] == self.token:
                    # win in row starting with board[i][j]
                    if j<=1:
                        count = 5
                        k = j
                        fiveInRow = True
                        while count>0 and fiveInRow:
                            fiveInRow = ( board.board[i][k]==self.token )
                            k = k + 1
                            count = count - 1
                        if fiveInRow:
                            numWins = numWins + 1
                    # win in col starting with board[i][j]
                    if i<=1:
                        count = 5
                        k = i
                        fiveInRow = True
                        while count>0 and fiveInRow:
                            fiveInRow = ( board.board[k][j]==self.token )
                            k = k + 1
                            count = count - 1
                        if fiveInRow:
                            numWins = numWins + 1
                    # win in main diag starting with board[i][j]
                    if i<=1 and j<=1:
                        count = 5
                        m = i
                        n = j
                        fiveInRow = True
                        while count>0 and fiveInRow:
                            fiveInRow = ( board.board[m][n]==self.token )
                            m = m + 1
                            n = n + 1
                            count = count - 1
                        if fiveInRow:
                            numWins = numWins + 1
                    # win in off diag starting with board[i][j]
                    if i<=1 and j>=4 :
                        count = 5
                        m = i
                        n = j
                        fiveInRow = True
                        while count>0 and fiveInRow:
                            fiveInRow = ( board.board[m][n]==self.token )
                            m = m + 1
                            n = n - 1
                            count = count - 1
                        if fiveInRow:
                            numWins = numWins + 1

        return (numWins>0)

    def explain_move(self,move, board):
    #---------------------------------------------------------------------------
    # Explain actions performed by move
    #---------------------------------------------------------------------------
        gameBlock = int(move[0])  # 1,2,3,4
        position = int(move[2])   # 1,2,3,4,5,6,7,8,9
        rotBlock = int(move[4])   # 1,2,3,4
        direction = move[5]       # L,R

        G = board.GRID_SIZE
        i = (position-1)//G + G*((gameBlock-1)//2) ;
        j = ((position-1)%G) + G*((gameBlock-1)%2) ;

        print("Placing " + self.token + " in cell [" + str(i) + "][" + str(j) +  \
              "], and rotating Block " + str(rotBlock) +  \
              (" Left" if direction=="L" else " Right.")) 
    
    def an948_h(self, board):
    #---------------------------------------------------------------------------
    # Heuristic evaluation of board, presuming it is player's move.
    # Student code needed here. Change userid to your drexel user id.
    # Heuristic should not do further lookahead by calling miniMax.  This
    # function estimates the value of the board at a terminal node.
    #---------------------------------------------------------------------------
        white_move = 0;
        black_move = 0;
        
        if self.token == "w": 
            white_move = 0;
        elif self.token == "b": 
            black_move = 0;
            
        for moves in board:
            if moves % 5 == 0: 
                white_move = white_move + 1;
            else: 
                black_move = black_move + 1;
            
            if white_move < black_move:
                heuristic = black_move;
            else: 
                heuristic = white_move;
            
            heuristic = (white_move + black_move) / 2;
        return heuristic;

    @abstractmethod
    def get_move(self, state):
        raise NotImplementedError
    
player = Player(1, "w", 2, 1000);
heuristic = player.an948_h([1, 2, 3, 5, 8]);
print(heuristic);


#---------------------------------------------------------------------------
# If the opponent is a human, the user is prompted to input a legal move.
#---------------------------------------------------------------------------
class Human(Player):

    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)
    
    def get_move(self, board):
        moveList = board.get_moves()
        move = None
        
        ValidMove = False
        while(not ValidMove):
            hMove = input(self.player_number +': Input your move (block/position block-to-rotate direction): ')

            for move in moveList:
                if move == hMove:
                    ValidMove = True
                    break

            if(not ValidMove):
                print('Invalid move.  ')

        return hMove


        
#---------------------------------------------------------------------------
# For random agent, a move is chosen at random from the list of legal moves.
#--------------------------------------------------------------------------- 
class Random(Player):
    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)
    
    #Part 2 of A4
    def choose_random_moves(self):
        pentago = PentagoBoard();
        random_moves = pentago.get_moves()
        return random_moves;
    
rand = Random(1, "w", 2, 1000);
move = rand.choose_random_moves()
print(move);
 
#---------------------------------------------------------------------------
# Use MiniMax algorithm to determine best move for player to make for given
# board. Complete get_move function.
# To examine each of player's moves and evaluate them with no lookahead,
# depth_limit is set to 1. To examine each of the opponent's moves, set depth_limit=2, etc.
# 
# Student code needed here.
#---------------------------------------------------------------------------
class Minimax(Player):
    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)
    
    #Part 3 of A4
    def minmax_value(self, state):
        #based on the minimax pseudocode implementation
        is_terminal = True
        i = range(state,)
        while(self.player_number == 1 or self.player_number == 2):
            if(is_terminal):
                return state;
            elif i == self.max_value(state):
                return self.max_value(state);
            elif i == self.min_value(state):
                return self.min_value(state);

    def max_value(self, state):
        v = float("-inf");
        for i in range(state,):
            v = max(v, self.minmax_value(i));
        return v;
    
    def min_value(self, state):
        v = float("inf");
        for i in range(state,):
            v = min(v, self.minmax_value(i));
        return v;
    
minmax = Minimax(1, "w", 2, 1000);
result = minmax.minmax_value(34);
print(result);
    
#---------------------------------------------------------------------------
# Use MiniMax algorithm with Alpha-Beta pruning to determine best move for player.
#---------------------------------------------------------------------------
class Alphabeta(Player):
    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)
    
    #Part 3 of A4, contd.
    def alphabeta(self, state, alpha, beta):
        #based on the minimax-alphabeta pruning pseudocode implementation
        def max_value(self, state, alpha, beta):
            v = float("-inf");
            for i in range(state,):
                v = max(v, min_value(self, i, alpha, beta));
                if v > beta or v == beta:
                    return v;
                alpha = max(alpha, v);
            return v;

        def min_value(self, state, alpha, beta):
            v = float("inf");
            for i in range(state,):
                v = min(v, max_value(self, i, alpha, beta));
                if v < alpha or v == alpha:
                    return v;
                beta = min(beta, v);
            return v;
 
alphabeta = Alphabeta(1, "w", 2, 1000);
result = alphabeta.alphabeta(34, 30, 40);
print(result);
#---------------------------------------------------------------------------
# Use MiniMax algorithm with Monte Carlo Tree Search to determine best move for player.
# This agent looks ahead only 2 moves, one for you and one for the opponent. After 
# this, use your heuristic to estimate the best n moves, with your own choice of n 
# (e.g., n=8), then use a Monte Carlo Tree Search to decide which of these is 
# best. You should design the playout function here. The playout function should 
# make alternating random moves for the player and opponent until the game ends, 
# either due to the player winning, the opponent winning (or possibly both!), or 
# the number of empty cells on the board being 0. (No winner!)
#---------------------------------------------------------------------------
class Minimax_mcts(Player):
    def __init__(self,player_number,token, depth_limit, time_limit):
        super().__init__(player_number,token, depth_limit, time_limit)

    #Part 4 of A4
    def mcts(self, state, player):
        #based on the mcts pseudocode implementation
        node = treelib.Node(state, player);
        while(node):
            if (node.is_leaf):
                child = node;
            else:
                child = node.successors;
            R = child.data;
            child.set_predecessor(tree_id=node,nid=R);
        return child;

monte_carlo = Minimax_mcts(1, "w", 2, 1000);
result = monte_carlo.mcts(34, 30);
print(result);