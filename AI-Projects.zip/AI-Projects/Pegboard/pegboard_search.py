#The first class defines the state of the pegboard, which is the populated board itself

import random

class State:    
    rows = 3;
    columns = 3;
    board = [];
        
    def __init__(self, rows, columns, board):
        self.rows = rows;
        self.columns = columns;
        self.board = [i for i in range(rows*columns)];
        
    
    #this function prints the filled-in grid    
    def __str__(self):
        for i in range(self.rows*self.columns): 
            self.board.append(random.randint(0,9));
            print(self.board.pop(i), end = " " if i % 4 else "\n")
        return str(self.board);
        
state = State(3, 3, [i for i in range(3*3)]);
print(state);

#The second class defines the behavior of the pieces of the pegboard

class Action(State):
    oldpos: int = 1;
    goner: int = 1;
    newpos: int = 0;
    
    def __init__(self, jumper, goner, newpos):
        self.jumper = jumper;
        self.goner = goner;
        self.newpos = newpos;
    
    #this function returns the State that results when applying an action to a given state. 
    # This does not change the value of state, but returns a new state -- 
    # be sure to return a deep copy in order to prevent side effects.
    def applyState(self, length, width, board, oldpos, goner, newpos):
        state = State(length, width, board);
        action = Action(oldpos, goner, newpos);
        for i in range((length-1)*(width-1)): newpos = state.board.pop(i) + action.goner;
        return newpos;
    
    def __str__(self):
        return 'The peg in ' + str(self.oldpos) + ' jumps to ' + str(self.newpos);
    
    #This function which returns True if the given action may be applied to state, that is, 
    # the preconditions are satisfied.
    def precondition(self, length, width, board, jumper, goner, newpos):
        return self.applyState(length, width, board, jumper, goner, newpos) == self.newpos;
    
    #This function calls precondition and returns a list of all possible actions that may be applied to the current state, where actions
    # have the form described above. This should be a list of all possible actions which
    # satisfy the preconditions for the given state.
    def applicableActions(self, length, width, board, jumper, goner, newpos):
        possible_actions = [];
        if self.precondition(length, width, board, jumper, goner, newpos):
            possible_actions.append(self.newpos);
        return possible_actions; 
    
    #This function which repeatedly tests goal(state) and if a goal has not been reached, determines all applicable
    # actions for the current state, chooses one randomly and applies it.
    def flailWildly(state: State):
        for i in range(state.board.__len__):
            return state.board.pop(i) == (1, 9);
    
    #This function returns True if state equals the state with exactly 1 peg, in position 9.    
    def goal(state):
        return state.board == [1,9];
    
    def heuristic1(self, length, width, board, jumper, goner, newpos):
        return self.applicableActions(length, width, board, jumper, goner, newpos)
    
    def heuristic2(state: State):
        for i in range(len(state.board)):
            for j in range(i+1):
                return abs(i-(i+1)) + abs(j-(j+1));    
    
action = Action(3, 4, 7);
print(action);

print(action.goal())

possible_actions = action.applicableActions(3, 3, [0, 2, 4], 0, 5, 5);
print(possible_actions);

##Assignment 3 --> DFS is vertical

def dfs(visited, board, node):
    if node not in visited:
        print (node)
        visited.add(node)
        for neighbor in board:
            dfs(visited, board, neighbor);
            
dfs(set(), [1, 3, 5, 7, 6, 1, 3, 4, 7], 1)            


#A-star algorithm
def a_star(start: Action):
    start.newpos = 0;
    heuristic = start.heuristic1(start.newpos, 3, 3, [0, 2, 4], 0, 5);
    #heuristic = start.heuristic2();
    open = [start];
    closed = [];
    while bool(open):
        n = open.remove(start);
        if start.goal(): return n;
        closed.append(n);
        for m, n in open:
            m.newpos = n.newpos + 1;
            m_heuristic = heuristic(m);
            open.add(m_heuristic);

            
action = Action(3, 4, 7);
print(a_star(action));
        
    
    

#def bfs(visited, board, node):
#    visited.append(node)
#    queue.append(node)
#    while queue:
#        s = queue.pop(0) 
#        print (s, end = " ") 
#        for neighbor in board:
#            if neighbor not in visited:
#                visited.append(neighbor)
#                queue.append(neighbor)
                
#bfs(visited, [1, 3, 5, 7, 6, 1, 3, 4, 7], 1)

#Heuristics are defined in the Action class