class Graph():
    #This class implements a graph with distinct vertices.
    
    def __init__(self, edges):
        self.edges = edges;
        self.graph_dict = {};
        for start, end in self.edges:
            if start in self.graph_dict:
                self.graph_dict[start].append(end);
            else:
                self.graph_dict[start] = [end];
        print("Graph: {}".format(self.graph_dict));

    def get_paths(self, start, end, path=[]):
        """_summary_

        This method/function returns all possible paths between two nodes.
        
        """
        path = path + [start];
        if start == end: return [path];
        if start not in self.graph_dict: return [];
        paths = [];
        for node in self.graph_dict[start]:
            if node not in path: 
                new_paths = self.get_paths(node, end, path);
                for p in new_paths: 
                    paths.append(p);
        return paths;

    def get_shortest_path(self, start, end, path=[]):
        """
        The Minimum Spanning Tree is used here to provide the shortest paths between any two nodes. To recap,
        this heuristic estimates the cost of completing a tour, given that a partial tour has already been 
        constructed. This function/method demonstrates a relaxed version of the TSP, because depending 
        on the start and end, it focuses on two adjacent nodes at a time and then compares the start and end nodes 
        towards the end.
        
        This code demonstrates that the MST heuristic dominates straight-line distance, because unlike straight-line
        distances which only cares about the start and end, the heuristic keeps track of all nodes in a path and 
        finds the closest unexplored node.
        """
        path = path + [start];
        if start == end: return path;
        if start not in self.graph_dict: return None;
        shortest_path = None;
        for node in self.graph_dict[start]:
            if node not in path:
                sp = self.get_shortest_path(node, end, path);
                if sp:
                    if shortest_path is None or len(sp) < len(shortest_path):
                        shortest_path = sp;
        return shortest_path;


if __name__ == '__main__':
    routes = [
        ("Paris", "Dubai"),
        ("Paris", "New York"),
        ("Dubai", "New York"),
        ("New York", "Toronto")
    ]
    
    graph = Graph(routes);