﻿using System;
using NUnit.Framework;
using Triangles;

namespace TriangleUnitTests
{
    [TestFixture]
    public class TestCases
    {
        Triangles.Triangles triangles;

        [SetUp]
        public void Setup() 
        {
            triangles = new Triangles.Triangles();
        }

        // Add your tests here!
    }
}
