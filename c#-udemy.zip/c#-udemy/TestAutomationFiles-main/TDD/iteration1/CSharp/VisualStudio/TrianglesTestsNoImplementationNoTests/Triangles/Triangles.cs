﻿using System;

namespace Triangles
{
    public class Triangles
    {
        public bool IsTriangle(double side1, double side2, double side3)
        {
            throw new NotImplementedException();
        }
    }
}
