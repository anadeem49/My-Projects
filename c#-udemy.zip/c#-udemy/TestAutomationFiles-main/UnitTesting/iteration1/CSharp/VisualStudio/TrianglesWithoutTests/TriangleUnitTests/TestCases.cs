﻿using System;
using NUnit.Framework;
using Triangles;

namespace TriangleUnitTests
{
    [TestFixture]
    public class TestCases
    {
        Triangles.Triangles triangles;

        [SetUp]
        public void Setup() 
        {
            triangles = new Triangles.Triangles();
        }

        // Add your tests here!
        [Test]
        public void ZeroInputs(){
            Assert.IsFalse(triangles.IsTriangle(0,0,0));
            Assert.IsFalse(triangles.IsTriangle(0,0,1));
            Assert.IsFalse(triangles.IsTriangle(0,1,0));
            Assert.IsFalse(triangles.IsTriangle(1,0,0));
            Assert.IsFalse(triangles.IsTriangle(0,1,1));
            Assert.IsFalse(triangles.IsTriangle(1,0,1));
            Assert.IsFalse(triangles.IsTriangle(1,1,0));
        }

        [Test]
        public void NegativeInputs(){
            Assert.IsFalse(triangles.IsTriangle(-1, -1, -1));
            Assert.IsFalse(triangles.IsTriangle(1, 1, -1));
            Assert.IsFalse(triangles.IsTriangle(1, -1, 1));
            Assert.IsFalse(triangles.IsTriangle(-1, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(1, -1, -1));
            Assert.IsFalse(triangles.IsTriangle(-1, 1, -1));
            Assert.IsFalse(triangles.IsTriangle(-1, -1, 1));
        }

        [Test]
        public void AllMaxValues(){
            Assert.IsFalse(triangles.IsTriangle(double.MaxValue, double.MaxValue, double.MaxValue));
        }

        [Test]
        public void NotTriangles(){
            Assert.IsFalse(triangles.IsTriangle(1, 1, 2));
            Assert.IsFalse(triangles.IsTriangle(1, 2, 1));
            Assert.IsFalse(triangles.IsTriangle(2, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(0.5, 0.5, 2));
            Assert.IsFalse(triangles.IsTriangle(0.5, 2, 0.5));
            Assert.IsFalse(triangles.IsTriangle(2, 0.5, 0.5));
        }

        [Test]
        public void AreTrianles(){
            Assert.IsFalse(triangles.IsTriangle(1, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(1, 2, 2));
            Assert.IsFalse(triangles.IsTriangle(3, 4, 5));
        }
    }
}
