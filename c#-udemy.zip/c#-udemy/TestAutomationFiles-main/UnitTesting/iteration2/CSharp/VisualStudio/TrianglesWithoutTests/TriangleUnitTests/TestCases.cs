﻿using System;
using NUnit.Framework;
using Triangles;

namespace TriangleUnitTests
{
    [TestFixture]
    public class TestCases
    {
        Triangles.Triangles triangles;

        [SetUp]
        public void Setup() 
        {
            triangles = new Triangles.Triangles();
        }


        [Test]
        public void ZeroInputs()
        {
            Assert.IsFalse(triangles.IsTriangle(0, 0, 0));
            Assert.IsFalse(triangles.IsTriangle(0, 0, 1));
            Assert.IsFalse(triangles.IsTriangle(0, 1, 0));
            Assert.IsFalse(triangles.IsTriangle(1, 0, 0));
            Assert.IsFalse(triangles.IsTriangle(0, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(1, 0, 1));
            Assert.IsFalse(triangles.IsTriangle(1, 1, 0));
        }

        [Test]
        public void NegativeInputs()
        {
            Assert.IsFalse(triangles.IsTriangle(-1, -1, -1));
            Assert.IsFalse(triangles.IsTriangle(1, 1, -1));
            Assert.IsFalse(triangles.IsTriangle(1, -1, 1));
            Assert.IsFalse(triangles.IsTriangle(-1, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(1, -1, -1));
            Assert.IsFalse(triangles.IsTriangle(-1, 1, -1));
            Assert.IsFalse(triangles.IsTriangle(-1, -1, 1));
        }

        [Test]
        public void AllMaxValue()
        {
            Assert.IsTrue(triangles.IsTriangle(double.MaxValue, double.MaxValue, double.MaxValue));
        }

        [Test]
        public void NotTriangles()
        {
            // two short sides equal the long side
            Assert.IsFalse(triangles.IsTriangle(1, 1, 2));
            Assert.IsFalse(triangles.IsTriangle(2, 1, 1));
            Assert.IsFalse(triangles.IsTriangle(1, 2, 1));
            // Two short sides are less than the long side
            Assert.IsFalse(triangles.IsTriangle(0.5, 0.5, 2));
            Assert.IsFalse(triangles.IsTriangle(0.5, 2, 0.5));
            Assert.IsFalse(triangles.IsTriangle(2, 0.5, 0.5));
        }

        [Test]
        public void AreTriangles()
        {
            Assert.IsTrue(triangles.IsTriangle(1, 1, 1));
            Assert.IsTrue(triangles.IsTriangle(1, 2, 2));
            Assert.IsTrue(triangles.IsTriangle(3, 4, 5));
        }

        [TestCase(1, 1, 1, "equilateral", TestName = "equilateral")]
        [TestCase(1, 2, 2, "isosceles", TestName = "isosceles")]
        [TestCase(3, 4, 5, "scalene", TestName = "scalene")]
        [TestCase(1, 1, 2, "Not a triangle", TestName = "not a triangle")]
        [TestCase(1, 1.00000001, 0.99999999, "scalene", TestName = "Scalene with rounding check")]
        public void TriangleTypes(double side1, double side2, double side3, string result)
        {
            string full = result;
            if (result != "Not a triangle"){
                full = $"{side1}, {side2}, {side3} forms a triangle of type: " + result;
            }
            Assert.AreEqual(full, triangles.OutputTriangleType(side1, side2, side3));
        }
    }
}
