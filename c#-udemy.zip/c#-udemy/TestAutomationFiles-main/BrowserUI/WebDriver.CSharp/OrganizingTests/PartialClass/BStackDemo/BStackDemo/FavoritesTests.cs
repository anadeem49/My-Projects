﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.Text;

namespace BStackDemo
{
    public partial class TestCases
    {
        [Test]
        public void VerifySelectedFavoritesShow() { }

        [Test]
        public void VerifyFavoritesCanBeRemoved() { }
    }
}
